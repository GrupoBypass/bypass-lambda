def process_data(event, context):
    print("test")
    return {"status": "success"}